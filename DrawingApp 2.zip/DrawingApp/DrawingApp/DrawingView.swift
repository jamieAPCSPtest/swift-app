import Foundation
import SwiftUI
import PencilKit

struct DrawingView : View {
    
    @State var drawingSizeTest: CGSize = CGSize(width: 350, height: 550)
    @State var canvasViewTest = PKCanvasView()
    @State var imageTest2: UIImage = UIImage()

    var body: some View {
        VStack {
            Image(uiImage: imageTest2)
                .resizable()
                .aspectRatio(drawingSizeTest, contentMode: .fit)
                .frame(height: 0)
            PenKitRepre(canvasViewTest: $canvasViewTest, drawingSizeTest: $drawingSizeTest)
                .frame(width: drawingSizeTest.width, height: drawingSizeTest.height)
                .border(Color.blue, width: 1) // sets up border of area to draw image
                                            // change background to grey, white border and white fill box !!!!
            
            // https://stackoverflow.com/questions/59981705/convert-drawing-to-an-image-with-pencilkit-in-swiftui
            
            
        }
    }

}

struct PenKitRepre : UIViewRepresentable {
    @Binding var canvasViewTest: PKCanvasView
    @Binding var drawingSizeTest: CGSize
    
    func makeUIView(context: Context) -> PKCanvasView {
        canvasViewTest.tool = PKInkingTool(.pen, color: .black, width: 3)
        canvasViewTest.drawingPolicy = .anyInput
        canvasViewTest.contentSize = drawingSizeTest
            //self.toolPicker.setVisible(true, forFirstResponder: canvasViewTest)
            //self.toolPicker.addObserver(canvasViewTest) -- USED TO ENABLE ABILITY
            //canvasViewTest.becomeFirstResponder()       -- TO CHANGE TOOLS ...
        return canvasViewTest                          // -- CURRENTLY NOT WORKING ...
    }
    
    func updateUIView(_ uiView: UIViewType, context: Context) {
    }
    
}
