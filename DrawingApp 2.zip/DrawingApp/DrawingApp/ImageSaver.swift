//
//  ImageSaver.swift
//  DrawingApp
//
//  Created by AP Computer Science on 4/18/23.
//

import UIKit
import PencilKit

/*

public extension UIWindow {
    func capture() -> UIImage {
        UIGraphicsBeginImageContextWithOptions(self.frame.size, true, UIScreen.main.scale)
        self.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
}

*/
 
/*
 
 public extension PKCanvasView {
     func captureDrawing() -> UIImage {
         UIGraphicsBeginImageContextWithOptions(self.frame.size, true, UIScreen.main.scale)
         self.layer.render(in: UIGraphicsGetCurrentContext()!)
         let imageDrawing = UIGraphicsGetImageFromCurrentImageContext()
         UIGraphicsEndImageContext()
         return imageDrawing!
     }
 }
 
*/
