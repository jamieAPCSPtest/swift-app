//
//  ViewController.swift
//  DrawingApp
//
//  Created by AP Computer Science on 4/17/23.
//
import SwiftUI
import UIKit
import PencilKit
import PhotosUI

public let canvasView: PKCanvasView = {
    let canvas = PKCanvasView()
    canvas.drawingPolicy = .anyInput
    //canvas.contentSize = CGSize(width: 350, height: 550)
    return canvas
}()

    //var drawingSize: CGSize = CGSize(width: 350, height: 550) /// test
    //let imgRect = CGRect(origin: CGPoint.zero, size: drawingSize) /// test
    //var imageTest: UIImage = UIImage() /// test

class ViewController: UIViewController, PKCanvasViewDelegate {
    
    @IBOutlet weak var pencilFingerButton: UIBarButtonItem!
    
        @State var drawingSize: CGSize = CGSize(width: 350, height: 550)
        @State var imageTest: UIImage = UIImage()
    
    let toolPicker = PKToolPicker.init()
    public let drawing = PKDrawing()
    
    override func viewDidLoad() {
        super.viewDidLoad()
            /// https://stackoverflow.com/questions/59981705/convert-drawing-to-an-image-with-pencilkit-in-swiftui
        // basically, trying to only screenshot the canvasView
        // so instead of a crop, trying to copy example from S-OF
        // ANYTHING LABELED WITH "/// TEST" IS ONLY SETUP TO USE THIS EXAMPLE
            ///imageTest(uiImage: imageTest)
            ///.resizable()
            ///.aspectRatio(drawingSize, contentMode: .fit)
            ///.frame(height: 100)
            
        canvasView.drawing = drawing
        canvasView.delegate = self
        view.addSubview(canvasView)
            ///imageTest = canvasView.drawing.image(from: imgRect, scale: 1.0) /// test
        // canvasView.contentSize = CGSize(width: 350, height: 550) WORKING
        canvasView.contentSize = drawingSize
        
        
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        canvasView.frame = view.bounds
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.toolPicker.setVisible(true, forFirstResponder: canvasView)
        self.toolPicker.addObserver(canvasView)
        canvasView.becomeFirstResponder()
    }
    
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    
    // Actual Canvas Functions
    
        func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
            
        }
        
        func canvasViewDidBeginUsingTool(_ canvasView: PKCanvasView) {
            
        }
        
        func canvasViewDidEndUsingTool(_ canvasView: PKCanvasView) {
            
        }
        
        func canvasViewDidFinishRendering(_ canvasView: PKCanvasView) {
            
        }
    
    @IBAction func saveDrawingToCameraRoll(_ sender: Any) {
        // UIImageWriteToSavedPhotosAlbum(getScreenshot() -> UIImage, self, #selector(saveWorked()), nil)
        let imgRect = CGRect(origin: CGPoint.zero, size: drawingSize)
        imageTest = canvasView.drawing.image(from: imgRect, scale: 1.0)
            ///
        let window: UIWindow! = UIApplication.shared.keyWindow
        
            /// let window: PKCanvasView! = UIApplication.shared.keyWindow
            let windowImage = window.capture()
            /// let windowImage = window.captureDrawing()
            UIImageWriteToSavedPhotosAlbum(windowImage, nil, nil, nil)
        
        let alert = UIAlertController(title: "Picture Has Been Saved!", message: "You can find this image in your camera roll.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.cancel))
            self.present(alert, animated: true)
    }

}

public extension UIWindow {
    func capture() -> UIImage {
        UIGraphicsBeginImageContextWithOptions(canvasView.frame.size, true, UIScreen.main.scale) // size, opaque, scale (scale = higher res)
        self.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
}


// https://stackoverflow.com/questions/25448879/how-do-i-take-a-full-screen-screenshot-in-swift
/*
 // optionally, video, other file :: https://www.hackingwithswift.com/books/ios-swiftui/saving-the-filtered-image-using-uiimagewritetosavedphotosalbum
 // 3 mins in lol
 // https://www.youtube.com/watch?v=PkJ9dB-Ou_w current video -- 3:11
 // https://www.youtube.com/watch?v=3d1HNBpqvuM old -- 9:18
 */
