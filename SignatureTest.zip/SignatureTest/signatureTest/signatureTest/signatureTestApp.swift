//
//  signatureTestApp.swift
//  signatureTest
//
//  Created by AP Computer Science on 4/27/23.
//

import SwiftUI

@main
struct signatureTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
