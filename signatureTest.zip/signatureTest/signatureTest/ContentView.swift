import SwiftUI
import PencilKit

struct ContentView : View {
    
    @State var canvasView = PKCanvasView()
    @State var drawingSize: CGSize = CGSize(width: 350, height: 80)
    @State var image: UIImage = UIImage()
    
    var body: some View {
        VStack {
            Image(uiImage: image)
                .resizable()
                .aspectRatio(drawingSize, contentMode: .fit)
                .frame(height: 100) // height of box, text, and button (increase = lower down)
            
            Text ("Sign here:")
            PenKitRepre(canvasView: $canvasView, drawingSize: $drawingSize)
                .frame(width: drawingSize.width, height: drawingSize.height)
                .border(/*@START_MENU_TOKEN@*/Color.black/*@END_MENU_TOKEN@*/, width: 3) // width = signature box thickness
            
            Button(action: {
                let imgRect = CGRect(origin: CGPoint.zero, size: drawingSize)
                image = canvasView.drawing.image(from: imgRect, scale: 0.0) // keep 0.0 for high-res
            }) {
                Text("Save")
            }
        }
    }
}


struct PenKitRepre : UIViewRepresentable {
    @Binding var canvasView: PKCanvasView
    @Binding var drawingSize: CGSize
    
    func makeUIView(context: Context) -> PKCanvasView {
        canvasView.tool = PKInkingTool(.pen, color: .black, width: 3)
        canvasView.drawingPolicy = .anyInput
        canvasView.contentSize = drawingSize
        return canvasView
    }
    
    func updateUIView(_ uiView: PKCanvasView, context: Context) {
        
    }
}
